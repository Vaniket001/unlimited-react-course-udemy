import React from "react";

const SingleProduct = () => {
    return (
        <div>
            <h2>SingleProduct</h2>
        </div>
    );
};

export default SingleProduct;
