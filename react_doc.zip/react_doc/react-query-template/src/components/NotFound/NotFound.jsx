import React from "react";

const NotFound = () => {
    return <h2 style={{ color: "red" }}>404 Page not found!!</h2>;
};

export default NotFound;
